-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2018 at 06:09 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cc`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouthome`
--

CREATE TABLE `abouthome` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `t1` varchar(50) NOT NULL,
  `t2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `abouthome`
--

INSERT INTO `abouthome` (`id`, `name`, `t1`, `t2`) VALUES
(3, 'Shuvo Broto', 'Website Developer', 'Android Developer'),
(4, 'Gonesh Chandra Das', 'Website Developer', 'Android Developer');

-- --------------------------------------------------------

--
-- Table structure for table `aboutme`
--

CREATE TABLE `aboutme` (
  `id` int(11) NOT NULL,
  `im` varchar(255) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `text1` text NOT NULL,
  `txt1` varchar(50) NOT NULL,
  `txt2` varchar(50) NOT NULL,
  `txt3` varchar(50) NOT NULL,
  `txt4` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aboutme`
--

INSERT INTO `aboutme` (`id`, `im`, `slogan`, `text1`, `txt1`, `txt2`, `txt3`, `txt4`) VALUES
(1, 'I am Shuvo Broto Das', 'I am web and android developer.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '', '', '', ''),
(2, 'I am Gonesh Chandra Das', 'Android Website Development and Java is my working sector', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', 'Website Developer', 'Android Developer', 'Ionic Framework', 'Logo Design'),
(3, 'I am Gonesh Chandra Das', 'Android Website Development and Java is my working sector', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `number1` bigint(13) NOT NULL,
  `address` varchar(50) NOT NULL,
  `addressdetails` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `emailaddress` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `phone`, `number1`, `address`, `addressdetails`, `email`, `emailaddress`) VALUES
(1, 'Phone', 2147483647, 'Address', '13/1  Ponitulla, Sylhet', 'Email', 'gonesh923@gmail.com'),
(2, 'Phone', 2147483647, 'Address', '13/1 Ponitulla, Sylhet', 'Email', 'gonesh923@gmail.com'),
(3, 'Phone', 8801994901067, 'Address', '13/1 Ponitulla, Sylhet', 'Email', 'gonesh923@gmail.com'),
(4, 'Cell Phone', 880175388282, 'Address', '13/1 Ponitulla, Sylhet', 'Contact Email', 'gonesh923@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(12) NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `subject`, `message`) VALUES
(25, 'Roni Das', 'roni123@gmail.com', 2147483647, 'Android', 'Hi Gonesh How are u?'),
(34, 'Gonesh Chandra Das', 'gonesh923@gmail.com', 2147483647, 'Android', 'Hi friends how are you?'),
(37, 'Gonesh Chandra Das', 'gonesh923@gmail.com', 2147483647, 'Mobile App', 'Hi friends'),
(39, 'Gonesh Chandra Das', 'gonesh923@gmail.com', 2147483647, 'Mobile App', 'Hi'),
(40, 'Gonesh Chandra Das', 'gonesh923@gmail.com', 2147483647, 'Mobile App', 'Hi'),
(41, 'Gonesh Chandra Das', 'gonesh923@gmail.com', 2147483647, 'Mobile App', 'Hi'),
(81, 'Broto', 'gonesh923@gmail.com', 2147483647, 'Web Design', 'hiohiohoihoihoohohiohooii'),
(82, 'Broto', 'gonesh923@gmail.com', 2147483647, 'Web Design', 'hiohiohoihoihoohohiohooii'),
(83, 'Broto', 'gonesh923@gmail.com', 2147483647, 'Web Design', 'hiohiohoihoihoohohiohooii'),
(85, 'ABC', 'abc@gmail.com', 2147483647, 'Web Design', 'Hi		\r\n								'),
(88, 'Dane', 'gonu923@gmail.com', 2147483647, 'Web design', '									\r\n								4564565465654'),
(89, 'Dane', 'gonu923@gmail.com', 2147483647, 'Web design', '																	4564565465654'),
(91, 'Dane', 'gonu923@gmail.com', 2147483647, 'Web design', 'Hi , Sundar.'),
(96, 'Titu', 'titu923@gmail.com', 2147483647, 'Web design', 'how are you?'),
(97, 'Dipankar', 'dipankar923@gmail.com', 17435812, 'Content Writing', '                  \r\n                '),
(98, 'Jani ', 'janisarkar.neub@gmail.com', 1753882283, 'Hello', 'Hello , How are you?');

-- --------------------------------------------------------

--
-- Table structure for table `footertxt`
--

CREATE TABLE `footertxt` (
  `id` int(11) NOT NULL,
  `text` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `footertxt`
--

INSERT INTO `footertxt` (`id`, `text`) VALUES
(1, 'Published by Gonesh Chandra Das'),
(2, 'Published and modified by Shuvo Broto Das'),
(3, 'Published and modified by Gonesh Chandra Das');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'Gonesh', '$2y$10$BFOdbtthHodQi7HhrCJa2eVGjp.ix7OdLES4G4oUJj3vT97s0pa2C'),
(2, 'Gon', '$2y$10$tucU3v.ugPeUJam9ChV6G.Wt4p0XQpMwHTjib0MRVjfDJ3kMjuLB2'),
(3, 'adminpanel', '$2y$10$KqLWbfJs6J/YO4B7CYH1tu/IW1hx6d8Px4T/iSHrRl/tfBU7hQQ9.');

-- --------------------------------------------------------

--
-- Table structure for table `meabout`
--

CREATE TABLE `meabout` (
  `id` int(10) NOT NULL,
  `im` varchar(255) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `text1` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meabout`
--

INSERT INTO `meabout` (`id`, `im`, `slogan`, `text1`) VALUES
(1, 'I am Gonesh Chandra Das', 'Android Website Development and Java is my working sector', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop p');

-- --------------------------------------------------------

--
-- Table structure for table `myskill`
--

CREATE TABLE `myskill` (
  `id` int(10) NOT NULL,
  `txt1` varchar(255) NOT NULL,
  `txt2` varchar(255) NOT NULL,
  `txt3` varchar(255) NOT NULL,
  `txt4` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `myskill`
--

INSERT INTO `myskill` (`id`, `txt1`, `txt2`, `txt3`, `txt4`) VALUES
(1, '', '', '', ''),
(2, 'Website Development', 'Android Development', 'Java', 'Logo Design');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`) VALUES
(21, 'Android Development', 'I Like to work with android. I Like to work with android. I Like to work with android. I Like to work with android.    '),
(23, 'Android Development', 'I am android and iOS apps developer.'),
(24, 'Java', 'I Like java. I like java. I Like java. I like java.I Like java. I like java. I Like java. I like java. I Like java. I like java.I Like java. I like java.      '),
(25, 'Web Development', 'Create field of web engineering. Create field of web engineering.                                         '),
(26, 'Website Design', ' Create field of web engineering.   Create field of web engineering.   Create field of web engineering.                                           '),
(40, 'Java', 'Java is an object oriented language. I have good command on JavaFX, Java Swing, GUI.    ');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(10) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `username`, `email`, `user_type`, `password`) VALUES
(1, 'Gonesh', 'gonu923@gmail.com', 'user', '7e4f8a3bd6dee43a51c0648bedbf326e'),
(2, 'Gonesh', 'gonu923@gmail.com', 'user', '7e4f8a3bd6dee43a51c0648bedbf326e'),
(3, 'Gonesh', 'gonu923@gmail.com', 'admin', '7e4f8a3bd6dee43a51c0648bedbf326e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouthome`
--
ALTER TABLE `abouthome`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aboutme`
--
ALTER TABLE `aboutme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footertxt`
--
ALTER TABLE `footertxt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meabout`
--
ALTER TABLE `meabout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `myskill`
--
ALTER TABLE `myskill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouthome`
--
ALTER TABLE `abouthome`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `aboutme`
--
ALTER TABLE `aboutme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `footertxt`
--
ALTER TABLE `footertxt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `meabout`
--
ALTER TABLE `meabout`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `myskill`
--
ALTER TABLE `myskill`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
